<?php

namespace Pterodactyl\Exceptions\Http\Base;

use Pterodactyl\Exceptions\DisplayException;

class InvalidPasswordProvidedException extends DisplayException
{
}
